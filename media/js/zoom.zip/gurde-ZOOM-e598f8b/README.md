ZOOM
====

jQuery photo gallery plugin

Works on: Chrome, Firefox, Safari, Opera and IE7+

You are free to use the ZOOM jQuery photo gallery plugin in any personal or commercial work without obligation of payment (monetary or otherwise) or attribution, however a credit for the work would be appreciated. Do not redistribute or sell (either in existing or modified form) and do not claim credit. Intellectual property rights are not transferred with the download of the plugin.